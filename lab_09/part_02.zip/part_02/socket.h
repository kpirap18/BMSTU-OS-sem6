#ifndef _CONSTANTS_H_

#define _CONSTANTS_H_

#define PORT 3436

#define MAX_LEN_BUF 64

#define TRUE 1
#define FALSE 0

#endif