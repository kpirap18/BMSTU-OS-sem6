#ifndef _SOCKET_H_
#define _SOCKET_H_

#define SOCKET_NAME "server_soc"
#define CLIENT_NAME "client_soc"
#define BUF_SIZE 256

#endif
